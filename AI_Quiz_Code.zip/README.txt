Goal State AI Quiz - DSC401-6 Artificial Intelligence, Units I & II

How to run: keep all four files in the same folder and open index.html in a browser.

index.html    page structure
style.css     layout, colours, light/dark themes
questions.js  the question bank (105 questions with answers, hints, explanations)
script.js     game logic: question selection, timer, scoring, lifelines, leaderboard
