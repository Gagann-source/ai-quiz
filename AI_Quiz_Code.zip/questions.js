/* Goal State AI Quiz - question bank (105 questions, Units I & II)
   t = type, d = difficulty, a = correct answer, rw = real-world, sp = search problem */
const QUIZ_DATA = {
 "topics": [
  {
   "id": "found",
   "name": "Foundations and Applications of AI",
   "unit": 1
  },
  {
   "id": "turing",
   "name": "Turing Test",
   "unit": 1
  },
  {
   "id": "rational",
   "name": "Rational Agents",
   "unit": 1
  },
  {
   "id": "intel",
   "name": "Intelligent Agents",
   "unit": 1
  },
  {
   "id": "agenv",
   "name": "Agents and Environments",
   "unit": 1
  },
  {
   "id": "good",
   "name": "Good Behaviour",
   "unit": 1
  },
  {
   "id": "nature",
   "name": "Nature of Environments",
   "unit": 1
  },
  {
   "id": "prob",
   "name": "Problems and Problem Spaces",
   "unit": 2
  },
  {
   "id": "state",
   "name": "State Space Search",
   "unit": 2
  },
  {
   "id": "prod",
   "name": "Production Systems",
   "unit": 2
  },
  {
   "id": "char",
   "name": "Problem Characteristics",
   "unit": 2
  },
  {
   "id": "issues",
   "name": "Issues in Search Program Design",
   "unit": 2
  },
  {
   "id": "bfs",
   "name": "Breadth-First Search",
   "unit": 2
  },
  {
   "id": "dfs",
   "name": "Depth-First Search",
   "unit": 2
  },
  {
   "id": "ids",
   "name": "Iterative Deepening",
   "unit": 2
  },
  {
   "id": "hill",
   "name": "Hill Climbing and its Variations",
   "unit": 2
  },
  {
   "id": "heur",
   "name": "Heuristic Search",
   "unit": 2
  },
  {
   "id": "best",
   "name": "Best First Search",
   "unit": 2
  },
  {
   "id": "csp",
   "name": "Constraint Satisfaction Problems",
   "unit": 2
  },
  {
   "id": "mea",
   "name": "Means-End Analysis",
   "unit": 2
  }
 ],
 "arOpts": [
  "Both A and R are true, and R is the correct explanation of A",
  "Both A and R are true, but R is not the correct explanation of A",
  "A is true, but R is false",
  "A is false, but R is true"
 ],
 "questions": [
  {
   "t": "mcq",
   "topic": "found",
   "d": "easy",
   "q": "Who coined the term \"Artificial Intelligence\" for the 1956 Dartmouth workshop?",
   "hint": "He also created the LISP programming language.",
   "exp": "John McCarthy proposed the name for the 1956 Dartmouth summer workshop, which is regarded as the birth of AI as a field.",
   "rw": false,
   "sp": false,
   "opts": [
    "John McCarthy",
    "Marvin Minsky",
    "Alan Turing",
    "Herbert Simon"
   ],
   "a": 0,
   "id": "Q001"
  },
  {
   "t": "mcq",
   "topic": "found",
   "d": "medium",
   "q": "Russell and Norvig group definitions of AI into four approaches. Which approach is the \"cognitive modelling\" approach?",
   "hint": "Cognitive science studies how the human mind actually works.",
   "exp": "Thinking humanly = cognitive modelling. Acting humanly = Turing Test approach, thinking rationally = laws of thought, acting rationally = rational agent approach.",
   "rw": false,
   "sp": false,
   "opts": [
    "Thinking humanly",
    "Acting humanly",
    "Acting rationally",
    "Thinking rationally"
   ],
   "a": 0,
   "id": "Q002"
  },
  {
   "t": "fib",
   "topic": "found",
   "d": "easy",
   "q": "The 1956 summer workshop regarded as the birthplace of AI was held at ______ College.",
   "hint": "A college in Hanover, New Hampshire, USA.",
   "exp": "The Dartmouth workshop (1956), organised by McCarthy, Minsky, Rochester and Shannon, launched AI as a field.",
   "rw": false,
   "sp": false,
   "ans": [
    "dartmouth"
   ],
   "id": "Q003"
  },
  {
   "t": "match",
   "topic": "found",
   "d": "medium",
   "q": "Match each early AI system with what it did.",
   "hint": "Two of these are expert systems from Stanford; one is from IBM; one is from MIT.",
   "exp": "MYCIN (medical diagnosis) and DENDRAL (chemistry) were expert systems, ELIZA (Weizenbaum, 1966) was an early chatbot, and IBM's Deep Blue beat Kasparov in 1997.",
   "rw": false,
   "sp": false,
   "pairs": [
    [
     "MYCIN",
     "Diagnosed blood infections (expert system)"
    ],
    [
     "Deep Blue",
     "Defeated world chess champion Kasparov"
    ],
    [
     "ELIZA",
     "Chatbot that imitated a psychotherapist"
    ],
    [
     "DENDRAL",
     "Inferred molecular structure from chemical data"
    ]
   ],
   "id": "Q004"
  },
  {
   "t": "tf",
   "topic": "found",
   "d": "easy",
   "q": "A system must copy the way the human brain works internally to be considered artificially intelligent.",
   "hint": "Do aeroplanes flap their wings like birds?",
   "exp": "False. The rational agent view judges a system by whether it acts to achieve the best expected outcome, not by whether it imitates human thought processes.",
   "rw": false,
   "sp": false,
   "a": false,
   "id": "Q005"
  },
  {
   "t": "scenario",
   "topic": "found",
   "d": "easy",
   "q": "A bank's system blocks a card payment made in another country five minutes after the same card was used in Bengaluru. Which AI application is this?",
   "hint": "The system noticed a pattern that does not fit the customer's normal behaviour.",
   "exp": "Fraud detection systems learn normal spending patterns and flag transactions that deviate from them.",
   "rw": true,
   "sp": false,
   "opts": [
    "Game playing",
    "Machine translation",
    "Fraud (anomaly) detection",
    "Speech recognition"
   ],
   "a": 2,
   "id": "Q006"
  },
  {
   "t": "scenario",
   "topic": "found",
   "d": "easy",
   "q": "An email service automatically moves messages such as \"You have won ₹50 lakh, click here\" into a separate folder. Which AI task is being performed?",
   "hint": "Each email gets one of two labels.",
   "exp": "Spam filtering is a classification task: the system assigns each email to the class spam or not-spam, usually with a learned model.",
   "rw": true,
   "sp": false,
   "opts": [
    "Classification",
    "Path planning",
    "Theorem proving",
    "Constraint satisfaction"
   ],
   "a": 0,
   "id": "Q007"
  },
  {
   "t": "mcq",
   "topic": "turing",
   "d": "easy",
   "q": "What does the Turing Test evaluate?",
   "hint": "Turing called it the \"imitation game\".",
   "exp": "In the Turing Test (1950), a human interrogator converses in writing with a human and a machine; the machine passes if the interrogator cannot reliably tell which is which.",
   "rw": false,
   "sp": false,
   "opts": [
    "Whether a machine's behaviour is indistinguishable from a human's in conversation",
    "Whether a machine has consciousness",
    "Whether a machine can compute faster than a human",
    "Whether a machine's internal reasoning is logically correct"
   ],
   "a": 0,
   "id": "Q008"
  },
  {
   "t": "mcq",
   "topic": "turing",
   "d": "medium",
   "q": "To pass the Total Turing Test, a computer needs two capabilities beyond those needed for the standard test. Which are they?",
   "hint": "The total test adds a video signal and physical objects passed through a hatch.",
   "exp": "The standard test needs NLP, knowledge representation, automated reasoning and machine learning. The Total Turing Test adds computer vision (to perceive) and robotics (to manipulate objects).",
   "rw": false,
   "sp": false,
   "opts": [
    "Computer vision and robotics",
    "Machine learning and knowledge representation",
    "Planning and theorem proving",
    "Natural language processing and automated reasoning"
   ],
   "a": 0,
   "id": "Q009"
  },
  {
   "t": "ar",
   "topic": "turing",
   "d": "medium",
   "q": "Assertion (A): A machine that passes the Turing Test is said to act humanly.\nReason (R): The Turing Test examines the internal reasoning process of the machine.",
   "hint": "The interrogator only sees typed answers.",
   "exp": "A is true, R is false. The test is purely behavioural: it looks only at the machine's responses, never at how they were produced.",
   "rw": false,
   "sp": false,
   "a": 2,
   "id": "Q010"
  },
  {
   "t": "fib",
   "topic": "turing",
   "d": "medium",
   "q": "The \"Chinese Room\" argument, which claims that passing the Turing Test does not prove understanding, was proposed by John ______.",
   "hint": "An American philosopher; the argument dates from 1980.",
   "exp": "John Searle argued that a system could manipulate symbols well enough to pass the test without understanding their meaning.",
   "rw": false,
   "sp": false,
   "ans": [
    "searle"
   ],
   "id": "Q011"
  },
  {
   "t": "scenario",
   "topic": "turing",
   "d": "easy",
   "q": "A website asks you to pick all the images containing traffic lights before you can log in. Which idea from AI is this based on?",
   "hint": "Here the judge is a computer and the task is to prove you are human.",
   "exp": "CAPTCHA stands for Completely Automated Public Turing test to tell Computers and Humans Apart. A machine judges whether the user is human, so it is a reverse Turing Test.",
   "rw": true,
   "sp": false,
   "opts": [
    "A production system",
    "A reverse Turing Test",
    "Hill climbing",
    "Means-end analysis"
   ],
   "a": 1,
   "id": "Q012"
  },
  {
   "t": "mcq",
   "topic": "rational",
   "d": "easy",
   "q": "A rational agent is one that",
   "hint": "Key word: expected.",
   "exp": "For each percept sequence, a rational agent selects the action expected to maximise its performance measure, given the evidence from its percepts and its built-in knowledge.",
   "rw": false,
   "sp": false,
   "opts": [
    "selects the action expected to maximise its performance measure, given its percepts and knowledge",
    "never makes a mistake",
    "imitates human decisions exactly",
    "always knows the actual outcome of its actions"
   ],
   "a": 0,
   "id": "Q013"
  },
  {
   "t": "tf",
   "topic": "rational",
   "d": "easy",
   "q": "Rationality is the same thing as omniscience.",
   "hint": "An omniscient agent would know the actual outcome of every action.",
   "exp": "False. Rationality maximises expected performance; omniscience (knowing actual outcomes) is impossible in reality.",
   "rw": false,
   "sp": false,
   "a": false,
   "id": "Q014"
  },
  {
   "t": "ar",
   "topic": "rational",
   "d": "medium",
   "q": "Assertion (A): A rational agent can choose an action that turns out to have a bad result.\nReason (R): Rationality maximises expected performance, not actual performance.",
   "hint": "Can an agent be blamed for something it could not perceive or predict?",
   "exp": "Both are true and R explains A. A rational choice is the best one given what the agent knows; unforeseeable events can still make it turn out badly.",
   "rw": false,
   "sp": false,
   "a": 0,
   "id": "Q015"
  },
  {
   "t": "scenario",
   "topic": "rational",
   "d": "medium",
   "q": "A delivery robot checks that the corridor is clear, starts crossing, and is hit by a ceiling panel that falls without warning. Was the robot's decision to cross irrational?",
   "hint": "Judge the decision, not the luck.",
   "exp": "The decision was rational. Rationality depends on the percept sequence so far and the agent's knowledge, not on outcomes it had no way of anticipating.",
   "rw": true,
   "sp": false,
   "opts": [
    "No, because it chose the best action given its percepts and knowledge",
    "Yes, because a rational agent must be omniscient",
    "No, because robots cannot be rational",
    "Yes, because the outcome was bad"
   ],
   "a": 0,
   "id": "Q016"
  },
  {
   "t": "mcq",
   "topic": "rational",
   "d": "medium",
   "q": "Which of these does the rationality of an agent at a given time NOT depend on?",
   "hint": "Rationality depends on four things: performance measure, prior knowledge, actions, percept sequence.",
   "exp": "Rationality depends on the performance measure, the agent's prior knowledge of the environment, the available actions and the percept sequence to date.",
   "rw": false,
   "sp": false,
   "opts": [
    "The performance measure that defines success",
    "The speed of the processor the agent runs on",
    "The actions the agent can perform",
    "The agent's percept sequence to date"
   ],
   "a": 1,
   "id": "Q017"
  },
  {
   "t": "mcq",
   "topic": "intel",
   "d": "easy",
   "q": "Which type of agent selects actions using only the current percept, ignoring the percept history?",
   "hint": "It works with condition–action rules.",
   "exp": "A simple reflex agent applies condition–action rules to the current percept only, so it works properly only in fully observable environments.",
   "rw": false,
   "sp": false,
   "opts": [
    "Simple reflex agent",
    "Goal-based agent",
    "Utility-based agent",
    "Model-based reflex agent"
   ],
   "a": 0,
   "id": "Q018"
  },
  {
   "t": "scenario",
   "topic": "intel",
   "d": "easy",
   "q": "A room thermostat switches the heater on whenever the temperature reading falls below 20°C and off otherwise. Which kind of agent is it?",
   "hint": "It reacts to the current reading with one fixed rule.",
   "exp": "The thermostat uses a single condition–action rule on the current percept, which makes it a simple reflex agent.",
   "rw": true,
   "sp": false,
   "opts": [
    "Learning agent",
    "Utility-based agent",
    "Goal-based agent",
    "Simple reflex agent"
   ],
   "a": 3,
   "id": "Q019"
  },
  {
   "t": "match",
   "topic": "intel",
   "d": "medium",
   "q": "Match each agent type with its defining feature.",
   "hint": "Each type adds one thing to the previous one: state, then goals, then degrees of preference.",
   "exp": "The four basic agent programs increase in generality: reflex rules, internal state (a model), goals, and a utility function for comparing goal-satisfying options.",
   "rw": false,
   "sp": false,
   "pairs": [
    [
     "Simple reflex agent",
     "Acts on the current percept using condition–action rules"
    ],
    [
     "Model-based reflex agent",
     "Keeps an internal state to track unseen parts of the world"
    ],
    [
     "Goal-based agent",
     "Chooses actions by considering whether they lead to a desired state"
    ],
    [
     "Utility-based agent",
     "Chooses actions that maximise a measure of how desirable a state is"
    ]
   ],
   "id": "Q020"
  },
  {
   "t": "scenario",
   "topic": "intel",
   "d": "hard",
   "q": "A ride-hailing app's autonomous cab can reach the airport by three routes. It compares them on travel time, fuel cost, safety and passenger comfort and picks the best overall trade-off. Which agent design does this need?",
   "hint": "All three routes reach the goal. What lets the agent say one is better than another?",
   "exp": "Goals only distinguish \"reached\" from \"not reached\". Choosing the best among several goal-achieving options, with conflicting objectives, needs a utility function.",
   "rw": true,
   "sp": false,
   "opts": [
    "Goal-based agent",
    "Utility-based agent",
    "Model-based reflex agent",
    "Simple reflex agent"
   ],
   "a": 1,
   "id": "Q021"
  },
  {
   "t": "fib",
   "topic": "intel",
   "d": "medium",
   "q": "A learning agent has four components: the learning element, the performance element, the critic and the ______ generator.",
   "hint": "It suggests exploratory actions that lead to new experiences.",
   "exp": "The problem generator suggests actions that lead to new and informative experiences; the critic gives feedback and the learning element improves the performance element.",
   "rw": false,
   "sp": false,
   "ans": [
    "problem"
   ],
   "id": "Q022"
  },
  {
   "t": "mcq",
   "topic": "agenv",
   "d": "easy",
   "q": "An agent perceives its environment through ______ and acts on it through ______.",
   "hint": "Eyes and hands, cameras and motors.",
   "exp": "An agent is anything that perceives its environment through sensors and acts upon it through actuators.",
   "rw": false,
   "sp": false,
   "opts": [
    "sensors; actuators",
    "rules; models",
    "actuators; sensors",
    "percepts; goals"
   ],
   "a": 0,
   "id": "Q023"
  },
  {
   "t": "fib",
   "topic": "agenv",
   "d": "medium",
   "q": "The agent ______ is the mathematical mapping from any percept sequence to an action.",
   "hint": "The agent program is the concrete implementation of this abstract thing.",
   "exp": "The agent function maps percept sequences to actions. The agent program implements it on some physical architecture.",
   "rw": false,
   "sp": false,
   "ans": [
    "function"
   ],
   "id": "Q024"
  },
  {
   "t": "tf",
   "topic": "agenv",
   "d": "easy",
   "q": "An agent can be described as architecture plus program.",
   "hint": "One part is the hardware with sensors and actuators, the other runs on it.",
   "exp": "True. Agent = architecture + program: the program implements the agent function and the architecture provides the sensors, actuators and computing device.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q025"
  },
  {
   "t": "problem",
   "topic": "agenv",
   "d": "easy",
   "q": "In the two-square vacuum world, the agent function is: if the current square is dirty then Suck; else move to the other square. The agent receives the percept [A, Dirty]. Which action does it take?",
   "hint": "Read the rule for a dirty square.",
   "exp": "The percept says the agent is in square A and it is dirty, so the rule gives Suck.",
   "rw": false,
   "sp": false,
   "opts": [
    "Right",
    "Left",
    "Suck",
    "NoOp"
   ],
   "a": 2,
   "id": "Q026"
  },
  {
   "t": "mcq",
   "topic": "agenv",
   "d": "medium",
   "q": "What is a percept sequence?",
   "hint": "A percept is one input at one instant; a sequence is…",
   "exp": "A percept is the agent's perceptual input at an instant; the percept sequence is the complete history of percepts. An agent's choice of action can depend on the whole sequence.",
   "rw": false,
   "sp": false,
   "opts": [
    "The set of rules stored in the agent program",
    "The complete history of everything the agent has perceived",
    "The list of actions an agent has performed",
    "The agent's current sensor reading only"
   ],
   "a": 1,
   "id": "Q027"
  },
  {
   "t": "mcq",
   "topic": "good",
   "d": "easy",
   "q": "In a PEAS description of a task environment, what does PEAS stand for?",
   "hint": "Two of the letters are how the agent senses and acts.",
   "exp": "PEAS = Performance measure, Environment, Actuators, Sensors. It is used to specify a task environment before designing an agent.",
   "rw": false,
   "sp": false,
   "opts": [
    "Percepts, Environment, Agents, States",
    "Performance measure, Events, Actions, Sensors",
    "Performance measure, Environment, Actuators, Sensors",
    "Problem, Evaluation, Actions, Search"
   ],
   "a": 2,
   "id": "Q028"
  },
  {
   "t": "scenario",
   "topic": "good",
   "d": "medium",
   "q": "You are writing the PEAS description for an automated taxi. Which of these belongs under Performance measure?",
   "hint": "The performance measure says what counts as doing the job well.",
   "exp": "Safe, fast, legal, comfortable trips (and profit) are the performance measure. Roads and traffic are the environment, steering and brakes are actuators, cameras and GPS are sensors.",
   "rw": true,
   "sp": false,
   "opts": [
    "Cameras, GPS and speedometer",
    "Roads, traffic, pedestrians and customers",
    "Steering, accelerator and brake",
    "Safe, fast, legal and comfortable trips"
   ],
   "a": 3,
   "id": "Q029"
  },
  {
   "t": "scenario",
   "topic": "good",
   "d": "medium",
   "q": "For a medical diagnosis system used in a hospital, which of these is an actuator in its PEAS description?",
   "hint": "Actuators are how the agent affects its environment.",
   "exp": "The system acts by displaying questions, tests, diagnoses and treatments. Keyboard entry is a sensor, patients and staff are the environment, and patient health and cost are the performance measure.",
   "rw": true,
   "sp": false,
   "opts": [
    "A healthy patient and reduced costs",
    "A screen displaying questions, tests and suggested treatments",
    "The patients and hospital staff",
    "The patient's symptoms entered on a keyboard"
   ],
   "a": 1,
   "id": "Q030"
  },
  {
   "t": "ar",
   "topic": "good",
   "d": "hard",
   "q": "Assertion (A): A performance measure should be designed according to what we actually want in the environment, not according to how we think the agent should behave.\nReason (R): A vacuum agent rewarded for the amount of dirt it sucks up could maximise its reward by dumping dirt back on the floor and cleaning it again.",
   "hint": "What would you reward instead: dirt collected, or a clean floor?",
   "exp": "Both are true and R explains A. Rewarding the behaviour (sucking dirt) invites cheating; rewarding the desired outcome (a clean floor over time) does not.",
   "rw": false,
   "sp": false,
   "a": 0,
   "id": "Q031"
  },
  {
   "t": "tf",
   "topic": "good",
   "d": "medium",
   "q": "A rational agent should gather information and learn from what it perceives, rather than rely only on its designer's prior knowledge.",
   "hint": "Think about the term \"autonomy\".",
   "exp": "True. Information gathering and learning are part of rationality. An agent that relies only on built-in knowledge lacks autonomy.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q032"
  },
  {
   "t": "mcq",
   "topic": "nature",
   "d": "medium",
   "q": "Chess played with a clock is best described as which kind of environment?",
   "hint": "The board does not change while a player thinks, but something else does.",
   "exp": "The board stays the same while the agent deliberates, but its score (through the clock) changes with time, so the environment is semidynamic.",
   "rw": false,
   "sp": false,
   "opts": [
    "Static",
    "Semidynamic",
    "Episodic",
    "Dynamic"
   ],
   "a": 1,
   "id": "Q033"
  },
  {
   "t": "scenario",
   "topic": "nature",
   "d": "hard",
   "q": "Which description fits the task environment of a self-driving taxi in city traffic?",
   "hint": "It is the hardest case on every dimension.",
   "exp": "The taxi cannot see everything, other drivers are unpredictable, each decision affects later ones, the world changes while it thinks, speeds and positions are continuous, and there are other agents.",
   "rw": true,
   "sp": false,
   "opts": [
    "Fully observable, deterministic, episodic, static, discrete, single-agent",
    "Fully observable, stochastic, episodic, dynamic, discrete, multi-agent",
    "Partially observable, deterministic, sequential, static, continuous, single-agent",
    "Partially observable, stochastic, sequential, dynamic, continuous, multi-agent"
   ],
   "a": 3,
   "id": "Q034"
  },
  {
   "t": "tf",
   "topic": "nature",
   "d": "easy",
   "q": "Solving a crossword puzzle is a fully observable, deterministic, static, single-agent task environment.",
   "hint": "Does anything change while you think? Is anything hidden?",
   "exp": "True. The whole grid and clues are visible, actions have certain effects, nothing changes while the solver thinks, and there is one agent.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q035"
  },
  {
   "t": "match",
   "topic": "nature",
   "d": "medium",
   "q": "Match each environment property with its meaning.",
   "hint": "The opposites are sequential, dynamic, stochastic and continuous.",
   "exp": "Episodic vs sequential, static vs dynamic, deterministic vs stochastic and discrete vs continuous are four of the standard dimensions for classifying task environments.",
   "rw": false,
   "sp": false,
   "pairs": [
    [
     "Episodic",
     "The current decision does not depend on earlier decisions"
    ],
    [
     "Static",
     "The environment does not change while the agent is deliberating"
    ],
    [
     "Deterministic",
     "The next state is fully determined by the current state and the action"
    ],
    [
     "Discrete",
     "There is a finite number of distinct states, percepts and actions"
    ]
   ],
   "id": "Q036"
  },
  {
   "t": "scenario",
   "topic": "nature",
   "d": "easy",
   "q": "An online poker bot cannot see the other players' cards. Which property of its environment does this describe?",
   "hint": "Its sensors do not give it the complete state.",
   "exp": "If the agent's sensors do not give access to the complete state of the environment, the environment is partially observable.",
   "rw": true,
   "sp": false,
   "opts": [
    "Deterministic",
    "Single-agent",
    "Static",
    "Partially observable"
   ],
   "a": 3,
   "id": "Q037"
  },
  {
   "t": "mcq",
   "topic": "prob",
   "d": "easy",
   "q": "Which of these is NOT part of the formal definition of a search problem?",
   "hint": "Three of them describe where you start, how you move and when you stop.",
   "exp": "A problem is defined by an initial state, operators/actions (successor function), a goal test and a path cost. A learning rate belongs to machine learning.",
   "rw": false,
   "sp": false,
   "opts": [
    "Learning rate",
    "Initial state",
    "Operators (actions)",
    "Goal test"
   ],
   "a": 0,
   "id": "Q038"
  },
  {
   "t": "fib",
   "topic": "prob",
   "d": "easy",
   "q": "The set of all states reachable from the initial state by any sequence of actions is called the state ______.",
   "hint": "Two words: state ______.",
   "exp": "The initial state and the operators together define the state space of the problem.",
   "rw": false,
   "sp": false,
   "ans": [
    "space"
   ],
   "id": "Q039"
  },
  {
   "t": "problem",
   "topic": "prob",
   "d": "medium",
   "q": "Water jug problem: you have a 4-litre jug and a 3-litre jug, both empty, and an unlimited tap. Allowed moves are fill a jug, empty a jug, or pour one into the other. What is the minimum number of moves needed to get exactly 2 litres in the 4-litre jug?",
   "hint": "Try: fill the 3, pour into the 4, fill the 3 again, top up the 4…",
   "exp": "One shortest solution, written (4L, 3L): (0,0) → (0,3) → (3,0) → (3,3) → (4,2) → (0,2) → (2,0). That is 6 moves, and breadth-first search confirms no shorter sequence exists.",
   "rw": false,
   "sp": true,
   "opts": [
    "4",
    "5",
    "6",
    "8"
   ],
   "a": 2,
   "id": "Q040"
  },
  {
   "t": "problem",
   "topic": "prob",
   "d": "hard",
   "q": "Missionaries and cannibals: 3 missionaries and 3 cannibals must cross a river in a boat that holds at most 2 people, and cannibals may never outnumber missionaries on either bank. What is the minimum number of one-way crossings?",
   "hint": "The boat must always carry someone back, so the answer is odd and larger than you first expect.",
   "exp": "The shortest solution takes 11 crossings. A state can be written (missionaries on left, cannibals on left, boat side), and breadth-first search over these states finds the 11-step path.",
   "rw": false,
   "sp": true,
   "opts": [
    "7",
    "9",
    "11",
    "13"
   ],
   "a": 2,
   "id": "Q041"
  },
  {
   "t": "mcq",
   "topic": "prob",
   "d": "medium",
   "q": "In the water jug problem, a state is written (x, y) where x is the amount in the 4-litre jug and y is the amount in the 3-litre jug. What does the rule (x, y) → (4, y) if x < 4 represent?",
   "hint": "Look at what x becomes.",
   "exp": "x becomes 4 while y is unchanged, so the rule fills the 4-litre jug from the tap. Each production rule in the problem is written this way.",
   "rw": false,
   "sp": true,
   "opts": [
    "Pour the 3-litre jug into the 4-litre jug",
    "Empty the 4-litre jug",
    "Fill the 3-litre jug",
    "Fill the 4-litre jug"
   ],
   "a": 3,
   "id": "Q042"
  },
  {
   "t": "mcq",
   "topic": "state",
   "d": "easy",
   "q": "In a state-space graph, what do the nodes and arcs represent?",
   "hint": "You move along an arc by doing something.",
   "exp": "Each node is a state of the problem and each arc is an operator that transforms one state into another.",
   "rw": false,
   "sp": false,
   "opts": [
    "Nodes are goals, arcs are heuristics",
    "Nodes are states, arcs are operators (actions)",
    "Nodes are rules, arcs are costs only",
    "Nodes are operators, arcs are states"
   ],
   "a": 1,
   "id": "Q043"
  },
  {
   "t": "tf",
   "topic": "state",
   "d": "easy",
   "q": "In state-space search, a solution is a path from the initial state to a goal state.",
   "hint": "Think about what the search algorithm returns.",
   "exp": "True. A solution is a sequence of operators leading from the initial state to a state that satisfies the goal test.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q044"
  },
  {
   "t": "problem",
   "topic": "state",
   "d": "medium",
   "q": "A search tree has branching factor 3. The root is at depth 0. How many nodes are there in total down to and including depth 3?",
   "hint": "Add 3⁰ + 3¹ + 3² + 3³.",
   "exp": "1 + 3 + 9 + 27 = 40 nodes.",
   "rw": false,
   "sp": true,
   "opts": [
    "27",
    "39",
    "40",
    "81"
   ],
   "a": 2,
   "id": "Q045"
  },
  {
   "t": "problem",
   "topic": "state",
   "d": "hard",
   "q": "The 8-puzzle has 9! = 362,880 possible arrangements of tiles. How many of them can actually be reached from a given start state?",
   "hint": "The arrangements split into two equal sets that cannot reach each other.",
   "exp": "Exactly half of the arrangements are reachable from any given state: 9!/2 = 181,440. The other half have the opposite parity.",
   "rw": false,
   "sp": true,
   "opts": [
    "362,880",
    "181,440",
    "40,320",
    "90,720"
   ],
   "a": 1,
   "id": "Q046"
  },
  {
   "t": "mcq",
   "topic": "prod",
   "d": "easy",
   "q": "Which of these is NOT a component of a production system?",
   "hint": "A production system has rules, a database, a control strategy and a rule applier.",
   "exp": "A production system consists of a set of rules, one or more knowledge/databases, a control strategy and a rule applier.",
   "rw": false,
   "sp": false,
   "opts": [
    "A set of rules",
    "One or more knowledge bases / working memory",
    "A control strategy",
    "A neural network trainer"
   ],
   "a": 3,
   "id": "Q047"
  },
  {
   "t": "fib",
   "topic": "prod",
   "d": "medium",
   "q": "In a production system, the ______ strategy decides the order in which rules are compared with the database and resolves conflicts when several rules match.",
   "hint": "It steers the search.",
   "exp": "The control strategy specifies which rule to apply next and how to resolve conflicts when more than one rule matches.",
   "rw": false,
   "sp": false,
   "ans": [
    "control"
   ],
   "id": "Q048"
  },
  {
   "t": "ar",
   "topic": "prod",
   "d": "medium",
   "q": "Assertion (A): A good control strategy must cause motion.\nReason (R): A control strategy that does not cause motion will never lead to a solution.",
   "hint": "Imagine always picking the first applicable rule in the water jug problem.",
   "exp": "Both are true and R explains A. The two requirements of a good control strategy are that it causes motion and that it is systematic.",
   "rw": false,
   "sp": false,
   "a": 0,
   "id": "Q049"
  },
  {
   "t": "match",
   "topic": "prod",
   "d": "hard",
   "q": "Match each class of production system with its definition.",
   "hint": "One of the three is defined as the combination of the other two.",
   "exp": "These are the classes described by Rich and Knight. Commutative systems are both monotonic and partially commutative.",
   "rw": false,
   "sp": false,
   "pairs": [
    [
     "Monotonic",
     "Applying one rule never prevents the later application of another rule that could have been applied at the same time"
    ],
    [
     "Partially commutative",
     "If a sequence of rules transforms state x into y, any allowable reordering of those rules also transforms x into y"
    ],
    [
     "Commutative",
     "Both monotonic and partially commutative"
    ]
   ],
   "id": "Q050"
  },
  {
   "t": "mcq",
   "topic": "prod",
   "d": "hard",
   "q": "Theorem proving is a typical example of which class of production system?",
   "hint": "Proving one lemma never stops you from proving another, and the order does not matter.",
   "exp": "Theorem proving is monotonic and partially commutative (commutative): steps can be ignored or reordered. Robot navigation is non-monotonic and partially commutative; chemical synthesis is monotonic but not partially commutative.",
   "rw": false,
   "sp": false,
   "opts": [
    "Non-monotonic, not partially commutative",
    "Monotonic, partially commutative",
    "Non-monotonic, partially commutative",
    "Monotonic, not partially commutative"
   ],
   "a": 1,
   "id": "Q051"
  },
  {
   "t": "match",
   "topic": "char",
   "d": "medium",
   "q": "Match each problem with the way its solution steps can be treated.",
   "hint": "Can you slide a tile back? Can you take back a chess move?",
   "exp": "Ignorable problems need only simple control, recoverable problems need backtracking, and irrecoverable problems need careful planning before each move.",
   "rw": false,
   "sp": false,
   "pairs": [
    [
     "Theorem proving",
     "Ignorable: a wrong step can simply be ignored"
    ],
    [
     "8-puzzle",
     "Recoverable: a wrong step can be undone"
    ],
    [
     "Chess",
     "Irrecoverable: a wrong step cannot be undone"
    ]
   ],
   "id": "Q052"
  },
  {
   "t": "tf",
   "topic": "char",
   "d": "medium",
   "q": "The Travelling Salesman Problem is an \"any-path\" problem, where any solution found is good enough.",
   "hint": "The salesman wants the shortest tour.",
   "exp": "False. TSP is a best-path problem: a solution is acceptable only if it is the best (shortest), so all paths must in principle be compared.",
   "rw": false,
   "sp": false,
   "a": false,
   "id": "Q053"
  },
  {
   "t": "scenario",
   "topic": "char",
   "d": "medium",
   "q": "A symbolic maths program is asked to integrate ∫(x² + 3x + sin²x·cos²x) dx. It splits the task into three separate integrals and solves each on its own. Which problem characteristic is it using?",
   "hint": "It breaks the problem into smaller independent parts.",
   "exp": "A decomposable problem can be split into smaller independent subproblems whose solutions are combined. Symbolic integration is the textbook example.",
   "rw": false,
   "sp": false,
   "opts": [
    "The problem is irrecoverable",
    "The solution is a path",
    "The universe is unpredictable",
    "The problem is decomposable"
   ],
   "a": 3,
   "id": "Q054"
  },
  {
   "t": "scenario",
   "topic": "char",
   "d": "medium",
   "q": "A medical expert system keeps asking the doctor for more test results and explains its reasoning before giving advice. Which problem characteristic does this reflect?",
   "hint": "The computer and the person talk back and forth.",
   "exp": "Problems are either solitary (the computer gets a description and returns an answer) or conversational (it interacts with a person for extra information or to explain itself). Medical diagnosis is conversational.",
   "rw": true,
   "sp": false,
   "opts": [
    "The problem requires interaction with a person",
    "The problem is ignorable",
    "The solution is absolute",
    "The problem is solitary"
   ],
   "a": 0,
   "id": "Q055"
  },
  {
   "t": "mcq",
   "topic": "char",
   "d": "medium",
   "q": "Playing bridge differs from solving the 8-puzzle because in bridge",
   "hint": "You cannot see the other players' cards.",
   "exp": "In the 8-puzzle the result of every move is certain, so a full plan can be made. In bridge the outcome is uncertain, so planning must allow for revision.",
   "rw": false,
   "sp": false,
   "opts": [
    "the problem is decomposable",
    "the solution is a state, not a path",
    "no knowledge is needed",
    "the outcome of actions is uncertain (the universe is not predictable)"
   ],
   "a": 3,
   "id": "Q056"
  },
  {
   "t": "mcq",
   "topic": "issues",
   "d": "medium",
   "q": "Which of these is NOT one of the standard issues in the design of search programs?",
   "hint": "Three of them are about direction, matching and representation.",
   "exp": "The issues are: direction of search, topology (tree vs graph), how each node is represented, and how applicable rules are selected (matching).",
   "rw": false,
   "sp": false,
   "opts": [
    "How to represent each node of the search (knowledge representation)",
    "The direction in which to search (forward or backward)",
    "How to select applicable rules (matching)",
    "Which brand of computer to run the program on"
   ],
   "a": 3,
   "id": "Q057"
  },
  {
   "t": "ar",
   "topic": "issues",
   "d": "medium",
   "q": "Assertion (A): Searching a graph instead of a tree can reduce the effort spent on a problem.\nReason (R): In a graph search, a node reached again by a different path is recognised and not expanded a second time.",
   "hint": "What happens in a tree search when the same state appears on two branches?",
   "exp": "Both are true and R explains A. A tree search may explore the same state many times; a graph search keeps track of generated nodes and avoids the duplicate work.",
   "rw": false,
   "sp": false,
   "a": 0,
   "id": "Q058"
  },
  {
   "t": "fib",
   "topic": "issues",
   "d": "easy",
   "q": "Reasoning from the goal state back towards the initial state is called ______ reasoning.",
   "hint": "The opposite of forward.",
   "exp": "Backward (goal-directed) reasoning starts from the goal and works back; forward (data-directed) reasoning starts from the initial state.",
   "rw": false,
   "sp": false,
   "ans": [
    "backward",
    "backwards",
    "goal directed",
    "goal-directed",
    "goaldirected",
    "backward chaining"
   ],
   "id": "Q059"
  },
  {
   "t": "mcq",
   "topic": "issues",
   "d": "hard",
   "q": "When is it usually better to reason backward from the goal rather than forward from the start state?",
   "hint": "Move from the smaller set of states towards the larger set.",
   "exp": "It is easier to search from a small set of states towards a large set. Other factors are the branching factor in each direction and whether the program must justify its reasoning.",
   "rw": false,
   "sp": false,
   "opts": [
    "When there is one start state and a very large number of goal states",
    "When no goal state is known",
    "When there are many possible start states but only a few goal states",
    "When the branching factor is much larger going backward"
   ],
   "a": 2,
   "id": "Q060"
  },
  {
   "t": "mcq",
   "topic": "bfs",
   "d": "easy",
   "q": "Which data structure does breadth-first search use to store the frontier?",
   "hint": "The oldest node generated is expanded first.",
   "exp": "BFS uses a FIFO queue, so the shallowest unexpanded node is always expanded next.",
   "rw": false,
   "sp": false,
   "opts": [
    "Hash table",
    "Stack (LIFO)",
    "Queue (FIFO)",
    "Priority queue ordered by h(n)"
   ],
   "a": 2,
   "id": "Q061"
  },
  {
   "t": "problem",
   "topic": "bfs",
   "d": "medium",
   "q": "Graph (children listed left to right):\nS → A, B\nA → C, D\nB → E\nD → G\nE → G\nC has no children. G is the goal.\n\nIn what order does breadth-first search visit the nodes, starting from S, until it reaches G?",
   "hint": "Finish each level completely before going deeper.",
   "exp": "BFS visits level by level: S (depth 0); A, B (depth 1); C, D, E (depth 2); then G (depth 3).",
   "rw": false,
   "sp": true,
   "opts": [
    "S, A, C, D, G",
    "S, A, B, C, D, E, G",
    "S, B, E, G",
    "S, A, B, D, E, C, G"
   ],
   "a": 1,
   "id": "Q062"
  },
  {
   "t": "tf",
   "topic": "bfs",
   "d": "medium",
   "q": "Breadth-first search is complete, and it is optimal when all step costs are equal.",
   "hint": "It always finds the shallowest goal first.",
   "exp": "True. With a finite branching factor BFS always finds a goal if one exists, and the shallowest goal is the cheapest when every step costs the same.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q063"
  },
  {
   "t": "scenario",
   "topic": "bfs",
   "d": "medium",
   "q": "A professional networking site wants to show \"2nd-degree\" and \"3rd-degree\" connections, i.e. the smallest number of links between you and another member. Which search strategy suits this best?",
   "hint": "You need the shortest chain where every link counts the same.",
   "exp": "BFS explores people one link away, then two links away, and so on, so the first time it reaches a member it has found the shortest chain.",
   "rw": true,
   "sp": true,
   "opts": [
    "Breadth-first search",
    "Means-end analysis",
    "Hill climbing",
    "Depth-first search"
   ],
   "a": 0,
   "id": "Q064"
  },
  {
   "t": "mcq",
   "topic": "bfs",
   "d": "medium",
   "q": "For branching factor b and shallowest goal depth d, what is the main drawback of breadth-first search?",
   "hint": "It keeps every node of the current level in memory.",
   "exp": "BFS has time and space complexity O(b^d). The exponential memory requirement is usually the bigger problem.",
   "rw": false,
   "sp": false,
   "opts": [
    "It needs a heuristic function",
    "It cannot find the shallowest goal",
    "It may never terminate on finite graphs",
    "Its memory requirement grows as O(b^d)"
   ],
   "a": 3,
   "id": "Q065"
  },
  {
   "t": "mcq",
   "topic": "dfs",
   "d": "easy",
   "q": "Which data structure does depth-first search use to store the frontier?",
   "hint": "The most recently generated node is expanded first.",
   "exp": "DFS uses a LIFO stack (or recursion), so it always expands the deepest unexpanded node.",
   "rw": false,
   "sp": false,
   "opts": [
    "Stack (LIFO)",
    "Circular buffer",
    "Priority queue",
    "Queue (FIFO)"
   ],
   "a": 0,
   "id": "Q066"
  },
  {
   "t": "problem",
   "topic": "dfs",
   "d": "medium",
   "q": "Graph (children listed left to right):\nS → A, B\nA → C, D\nB → E\nD → G\nE → G\nC has no children. G is the goal.\n\nIn what order does depth-first search visit the nodes, starting from S and taking the leftmost child first, until it reaches G?",
   "hint": "Go as deep as possible; back up only at a dead end.",
   "exp": "DFS goes S → A → C (dead end), backtracks to A, then D → G. Order: S, A, C, D, G.",
   "rw": false,
   "sp": true,
   "opts": [
    "S, A, B, C, D, E, G",
    "S, A, C, D, G",
    "S, B, E, G",
    "S, A, D, G"
   ],
   "a": 1,
   "id": "Q067"
  },
  {
   "t": "tf",
   "topic": "dfs",
   "d": "easy",
   "q": "Depth-first search always finds the shortest path to the goal.",
   "hint": "It commits to one branch before looking at the others.",
   "exp": "False. DFS returns the first goal it meets along its current branch, which may be deeper than another goal. It is not optimal, and it can fail to terminate in infinite-depth spaces.",
   "rw": false,
   "sp": false,
   "a": false,
   "id": "Q068"
  },
  {
   "t": "ar",
   "topic": "dfs",
   "d": "medium",
   "q": "Assertion (A): Depth-first search is guaranteed to find the shallowest goal node.\nReason (R): Depth-first search stores its frontier in a stack (LIFO).",
   "hint": "Check each statement separately first.",
   "exp": "A is false and R is true. DFS does use a stack, but that is exactly why it dives deep and can miss a shallower goal on another branch.",
   "rw": false,
   "sp": false,
   "a": 3,
   "id": "Q069"
  },
  {
   "t": "mcq",
   "topic": "dfs",
   "d": "medium",
   "q": "For branching factor b and maximum depth m, what is the space complexity of depth-first search?",
   "hint": "It stores one path plus the unexpanded siblings along it.",
   "exp": "DFS needs only O(bm) memory: the current path of length m and up to b siblings at each level. This linear space is its main advantage.",
   "rw": false,
   "sp": false,
   "opts": [
    "O(bm)",
    "O(m^b)",
    "O(b^m)",
    "O(b + m)"
   ],
   "a": 0,
   "id": "Q070"
  },
  {
   "t": "mcq",
   "topic": "ids",
   "d": "medium",
   "q": "Iterative deepening depth-first search combines which two advantages?",
   "hint": "It runs DFS repeatedly with depth limits 0, 1, 2, …",
   "exp": "IDS is complete and optimal (for equal step costs) like BFS, but needs only O(bd) memory like DFS.",
   "rw": false,
   "sp": false,
   "opts": [
    "The optimality of DFS with the memory use of BFS",
    "The heuristic of best-first search with the stack of DFS",
    "The completeness and optimality of BFS with the low memory use of DFS",
    "The speed of hill climbing and the memory of A*"
   ],
   "a": 2,
   "id": "Q071"
  },
  {
   "t": "problem",
   "topic": "ids",
   "d": "hard",
   "q": "A search tree has branching factor b = 10 and the goal is at depth d = 5. Not counting the root, how many nodes does iterative deepening search generate in total?",
   "hint": "Depth-1 nodes are generated 5 times, depth-2 nodes 4 times, … depth-5 nodes once.",
   "exp": "N(IDS) = 5(10) + 4(100) + 3(1,000) + 2(10,000) + 1(100,000) = 123,450. Breadth-first search generates 111,110, so the repeated work adds only about 11%.",
   "rw": false,
   "sp": true,
   "opts": [
    "111,110",
    "123,450",
    "100,000",
    "555,550"
   ],
   "a": 1,
   "id": "Q072"
  },
  {
   "t": "ar",
   "topic": "ids",
   "d": "hard",
   "q": "Assertion (A): Iterative deepening regenerates the upper levels of the tree many times, yet it is not much more expensive than breadth-first search.\nReason (R): In a search tree with a constant branching factor, most of the nodes are in the bottom level.",
   "hint": "Compare how many nodes are at depth 5 with how many are at depths 1–4, for b = 10.",
   "exp": "Both are true and R explains A. The upper levels are small compared with the deepest level, so regenerating them costs little.",
   "rw": false,
   "sp": false,
   "a": 0,
   "id": "Q073"
  },
  {
   "t": "fib",
   "topic": "ids",
   "d": "easy",
   "q": "Depth-first search with a fixed cut-off on how deep it may go is called depth-______ search.",
   "hint": "Depth-______ search (DLS).",
   "exp": "Depth-limited search treats nodes at the limit as if they had no successors. Iterative deepening calls it repeatedly with an increasing limit.",
   "rw": false,
   "sp": false,
   "ans": [
    "limited",
    "limit",
    "bounded"
   ],
   "id": "Q074"
  },
  {
   "t": "tf",
   "topic": "ids",
   "d": "medium",
   "q": "Iterative deepening search is the preferred uninformed method when the search space is large and the depth of the solution is not known.",
   "hint": "Think about what BFS and DFS each lack in that situation.",
   "exp": "True. BFS would run out of memory and DFS might never return; IDS avoids both problems.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q075"
  },
  {
   "t": "mcq",
   "topic": "hill",
   "d": "easy",
   "q": "Which of these is NOT a typical problem faced by hill climbing?",
   "hint": "Hill climbing keeps only the current state.",
   "exp": "Hill climbing can get stuck on local maxima, plateaus and ridges. It uses very little memory because it stores just the current state.",
   "rw": false,
   "sp": false,
   "opts": [
    "Plateau",
    "Exponential memory use",
    "Ridge",
    "Local maximum"
   ],
   "a": 1,
   "id": "Q076"
  },
  {
   "t": "mcq",
   "topic": "hill",
   "d": "medium",
   "q": "How does steepest-ascent hill climbing differ from simple hill climbing?",
   "hint": "\"Steepest\" means the biggest improvement available.",
   "exp": "Simple hill climbing moves to the first successor that is better than the current state. Steepest-ascent compares all successors and picks the best.",
   "rw": false,
   "sp": false,
   "opts": [
    "It accepts worse states with some probability",
    "It restarts from a random state after every move",
    "It examines all successors and moves to the best one, instead of taking the first better one",
    "It keeps a queue of all states generated so far"
   ],
   "a": 2,
   "id": "Q077"
  },
  {
   "t": "match",
   "topic": "hill",
   "d": "medium",
   "q": "Match each hill-climbing difficulty with its description.",
   "hint": "Picture a small hill, a flat field and a narrow sloping crest.",
   "exp": "Usual remedies: backtrack or restart for a local maximum, make a big jump for a plateau, and apply several rules at once for a ridge.",
   "rw": false,
   "sp": false,
   "pairs": [
    [
     "Local maximum",
     "A state better than all its neighbours but not the best state overall"
    ],
    [
     "Plateau",
     "A flat area where neighbouring states all have the same value"
    ],
    [
     "Ridge",
     "A rising area that cannot be climbed by single moves in any one direction"
    ]
   ],
   "id": "Q078"
  },
  {
   "t": "problem",
   "topic": "hill",
   "d": "hard",
   "q": "Steepest-ascent hill climbing (maximising) starts at A, whose value is 10. A's neighbours are B (12) and C (15). C's neighbours are D (14) and E (13). B's neighbour is F (20). Where does the search stop?",
   "hint": "From A it takes the best neighbour. Then check that state's neighbours.",
   "exp": "From A the best neighbour is C (15). Both of C's neighbours are worse, so the search stops at C, a local maximum, and never finds F (20).",
   "rw": false,
   "sp": true,
   "opts": [
    "At F with value 20",
    "At C with value 15",
    "At B with value 12",
    "At D with value 14"
   ],
   "a": 1,
   "id": "Q079"
  },
  {
   "t": "scenario",
   "topic": "hill",
   "d": "hard",
   "q": "A chip design tool rearranges components to shorten wiring. It usually accepts only improvements, but early on it sometimes accepts a worse layout, and it does this less and less often as the run goes on. Which algorithm is this?",
   "hint": "The name comes from slowly cooling metal.",
   "exp": "Simulated annealing is a variation of hill climbing that accepts bad moves with a probability that falls as the \"temperature\" is lowered, letting it escape local optima. VLSI layout is a classic application.",
   "rw": true,
   "sp": false,
   "opts": [
    "Breadth-first search",
    "Simulated annealing",
    "Depth-limited search",
    "Steepest-ascent hill climbing"
   ],
   "a": 1,
   "id": "Q080"
  },
  {
   "t": "ar",
   "topic": "hill",
   "d": "medium",
   "q": "Assertion (A): Hill climbing is a local search method.\nReason (R): Hill climbing can get stuck on a plateau.",
   "hint": "Both may be true without one being the cause of the other.",
   "exp": "Both are true, but R does not explain A. Hill climbing is local because it keeps only the current state and looks only at its neighbours; the plateau problem is a consequence, not the reason.",
   "rw": false,
   "sp": false,
   "a": 1,
   "id": "Q081"
  },
  {
   "t": "mcq",
   "topic": "heur",
   "d": "easy",
   "q": "In heuristic search, what does the heuristic function h(n) estimate?",
   "hint": "It looks ahead, not back.",
   "exp": "h(n) is the estimated cost of the cheapest path from node n to a goal state. The cost already spent to reach n is g(n).",
   "rw": false,
   "sp": false,
   "opts": [
    "The cost of the path from the start node to n",
    "The depth of node n in the tree",
    "The number of nodes generated so far",
    "The cost of the cheapest path from n to a goal"
   ],
   "a": 3,
   "id": "Q082"
  },
  {
   "t": "problem",
   "topic": "heur",
   "d": "medium",
   "q": "8-puzzle.\nCurrent state:\n2 8 3\n1 6 4\n7 _ 5\nGoal state:\n1 2 3\n8 _ 4\n7 6 5\n\nWhat is the Manhattan distance heuristic for the current state?",
   "hint": "Only tiles 2, 8, 1 and 6 are out of place. Add up how many squares each must move.",
   "exp": "Tile 2 needs 1 move, tile 8 needs 2, tile 1 needs 1 and tile 6 needs 1, so h = 5. (The misplaced-tiles heuristic would give 4.)",
   "rw": false,
   "sp": true,
   "opts": [
    "3",
    "4",
    "5",
    "6"
   ],
   "a": 2,
   "id": "Q083"
  },
  {
   "t": "fib",
   "topic": "heur",
   "d": "easy",
   "q": "In A* search the evaluation function is f(n) = g(n) + ______.",
   "hint": "Cost so far plus the estimated cost to go.",
   "exp": "f(n) = g(n) + h(n): the cost to reach n plus the estimated cost from n to the goal.",
   "rw": false,
   "sp": false,
   "ans": [
    "h(n)",
    "h",
    "hn"
   ],
   "id": "Q084"
  },
  {
   "t": "scenario",
   "topic": "heur",
   "d": "medium",
   "q": "A maps app finding a driving route from Bengaluru to Mysuru guides its search using the straight-line distance from each junction to Mysuru. Why is this a good heuristic for A*?",
   "hint": "No road can be shorter than a straight line.",
   "exp": "Straight-line distance never overestimates the actual road distance, so it is admissible, and A* with an admissible heuristic finds an optimal route.",
   "rw": true,
   "sp": true,
   "opts": [
    "It removes the need for a goal test",
    "It always equals the true road distance",
    "It never overestimates the true road distance, so it is admissible",
    "It makes the search uninformed"
   ],
   "a": 2,
   "id": "Q085"
  },
  {
   "t": "problem",
   "topic": "heur",
   "d": "hard",
   "q": "Edges and costs: S→A = 1, S→B = 4, A→G = 3, B→G = 5.\nHeuristic values: h(S) = 4, h(A) = 3, h(B) = 2, h(G) = 0.\n\nWhich path does A* search return from S to G, and what does it cost?",
   "hint": "Compute f = g + h for A and for B.",
   "exp": "f(A) = 1 + 3 = 4 and f(B) = 4 + 2 = 6, so A* expands A, reaches G with f = 4, and returns S → A → G with cost 4, the optimal path.",
   "rw": false,
   "sp": true,
   "opts": [
    "S → B → G, cost 9",
    "S → A → G, cost 4",
    "S → A → G, cost 9",
    "S → B → G, cost 6"
   ],
   "a": 1,
   "id": "Q086"
  },
  {
   "t": "mcq",
   "topic": "heur",
   "d": "medium",
   "q": "A heuristic is admissible if it",
   "hint": "An admissible heuristic is optimistic.",
   "exp": "An admissible heuristic never overestimates the true cost to the goal. Misplaced tiles and Manhattan distance are admissible for the 8-puzzle.",
   "rw": false,
   "sp": false,
   "opts": [
    "never overestimates the cost of reaching the goal",
    "is always equal to zero",
    "never underestimates the cost of reaching the goal",
    "is computed by a neural network"
   ],
   "a": 0,
   "id": "Q087"
  },
  {
   "t": "mcq",
   "topic": "best",
   "d": "easy",
   "q": "Greedy best-first search always expands the node that",
   "hint": "It trusts the heuristic alone.",
   "exp": "Greedy best-first search uses f(n) = h(n) and expands the node with the lowest heuristic value.",
   "rw": false,
   "sp": false,
   "opts": [
    "is deepest in the tree",
    "was generated first",
    "has the lowest path cost g(n)",
    "appears closest to the goal according to h(n)"
   ],
   "a": 3,
   "id": "Q088"
  },
  {
   "t": "problem",
   "topic": "best",
   "d": "hard",
   "q": "Edges and costs: S→A = 1, S→B = 4, A→G = 3, B→G = 5.\nHeuristic values: h(S) = 4, h(A) = 3, h(B) = 2, h(G) = 0.\n\nWhich path does greedy best-first search return from S to G, and what does it cost?",
   "hint": "Greedy search looks only at h. Which of A and B looks closer?",
   "exp": "h(B) = 2 is lower than h(A) = 3, so greedy search expands B and then reaches G: S → B → G, cost 4 + 5 = 9. The cheaper path through A (cost 4) is missed.",
   "rw": false,
   "sp": true,
   "opts": [
    "S → A → G, cost 4",
    "S → B → G, cost 9",
    "S → B → G, cost 2",
    "S → A → G, cost 3"
   ],
   "a": 1,
   "id": "Q089"
  },
  {
   "t": "tf",
   "topic": "best",
   "d": "easy",
   "q": "Greedy best-first search is guaranteed to find the optimal solution.",
   "hint": "It ignores the cost already paid to reach a node.",
   "exp": "False. Because it ignores g(n), greedy best-first search can return a more expensive path.",
   "rw": false,
   "sp": false,
   "a": false,
   "id": "Q090"
  },
  {
   "t": "fib",
   "topic": "best",
   "d": "medium",
   "q": "The best-first search algorithm keeps two lists: OPEN, for nodes generated but not yet examined, and ______, for nodes already examined.",
   "hint": "The opposite of OPEN.",
   "exp": "OPEN is a priority queue of nodes waiting to be expanded; CLOSED holds nodes already expanded, so that repeated states can be detected.",
   "rw": false,
   "sp": false,
   "ans": [
    "closed"
   ],
   "id": "Q091"
  },
  {
   "t": "mcq",
   "topic": "best",
   "d": "medium",
   "q": "Best-first search is often described as combining the advantages of which two methods?",
   "hint": "It follows one promising path but can switch to another when that path looks worse.",
   "exp": "Like DFS it follows a single path without expanding every branch; like BFS it does not get trapped on dead ends, because it can switch to a more promising node on OPEN.",
   "rw": false,
   "sp": false,
   "opts": [
    "Depth-first search and breadth-first search",
    "Forward chaining and backward chaining",
    "Hill climbing and simulated annealing",
    "Means-end analysis and constraint satisfaction"
   ],
   "a": 0,
   "id": "Q092"
  },
  {
   "t": "mcq",
   "topic": "csp",
   "d": "easy",
   "q": "A constraint satisfaction problem is defined by which three components?",
   "hint": "Think of map colouring: regions, colours and the adjacency rule.",
   "exp": "A CSP has a set of variables, a domain of possible values for each variable, and constraints that specify the allowed combinations of values.",
   "rw": false,
   "sp": false,
   "opts": [
    "States, operators and path costs",
    "Rules, working memory and control strategy",
    "Variables, domains and constraints",
    "Percepts, actions and goals"
   ],
   "a": 2,
   "id": "Q093"
  },
  {
   "t": "scenario",
   "topic": "csp",
   "d": "medium",
   "q": "A university must schedule end-semester exams so that no student has two exams at once, no hall is double-booked and every exam fits in its hall. How is this problem best modelled?",
   "hint": "Exams need values (slot, hall) that respect a list of restrictions.",
   "exp": "Timetabling is a classic CSP: variables are exams, domains are time slots and halls, and the constraints forbid clashes and over-capacity.",
   "rw": true,
   "sp": false,
   "opts": [
    "As a simple reflex agent",
    "As a constraint satisfaction problem",
    "As breadth-first search on a tree of halls",
    "As a Turing Test"
   ],
   "a": 1,
   "id": "Q094"
  },
  {
   "t": "problem",
   "topic": "csp",
   "d": "medium",
   "q": "Map colouring of Australia with three colours (red, green, blue). Western Australia (WA) borders NT and SA; Northern Territory (NT) borders WA, SA and Queensland (Q); South Australia (SA) borders WA, NT and Q. If WA = red and NT = green, what colour must Q be?",
   "hint": "First work out the only colour left for SA.",
   "exp": "SA touches WA (red) and NT (green), so SA = blue. Q touches NT (green) and SA (blue), so Q must be red.",
   "rw": false,
   "sp": true,
   "opts": [
    "Red",
    "Green",
    "Blue",
    "Any of the three"
   ],
   "a": 0,
   "id": "Q095"
  },
  {
   "t": "problem",
   "topic": "csp",
   "d": "hard",
   "q": "In the cryptarithmetic puzzle SEND + MORE = MONEY, each letter stands for a different digit. What must the value of M be?",
   "hint": "M is the carry out of the leftmost column.",
   "exp": "Adding two 4-digit numbers gives at most 19,998, so the leading digit of the 5-digit result is 1. Hence M = 1. (The full solution is 9567 + 1085 = 10652.)",
   "rw": false,
   "sp": true,
   "opts": [
    "0",
    "1",
    "2",
    "9"
   ],
   "a": 1,
   "id": "Q096"
  },
  {
   "t": "mcq",
   "topic": "csp",
   "d": "medium",
   "q": "In backtracking search for CSPs, what does the minimum remaining values (MRV) heuristic do?",
   "hint": "It is also called the \"most constrained variable\" heuristic.",
   "exp": "MRV chooses the variable with the fewest remaining legal values, so that failures are detected early.",
   "rw": false,
   "sp": false,
   "opts": [
    "Picks variables in alphabetical order",
    "Picks the variable with the largest domain",
    "Picks the value that rules out the fewest choices for neighbours",
    "Picks the variable with the fewest legal values left"
   ],
   "a": 3,
   "id": "Q097"
  },
  {
   "t": "ar",
   "topic": "csp",
   "d": "medium",
   "q": "Assertion (A): Backtracking search for CSPs is a form of depth-first search.\nReason (R): Breadth-first search uses less memory than depth-first search.",
   "hint": "Recall the space complexities O(b^d) and O(bm).",
   "exp": "A is true and R is false. Backtracking assigns one variable at a time depth-first; BFS uses far more memory than DFS.",
   "rw": false,
   "sp": false,
   "a": 2,
   "id": "Q098"
  },
  {
   "t": "scenario",
   "topic": "csp",
   "d": "medium",
   "q": "A Sudoku-solving app treats each of the 81 cells as a variable with domain 1–9. What plays the role of the constraints?",
   "hint": "What rule makes a filled grid valid?",
   "exp": "Sudoku is a CSP with 27 \"all different\" constraints: 9 rows, 9 columns and 9 boxes.",
   "rw": true,
   "sp": false,
   "opts": [
    "The time limit for solving the puzzle",
    "All digits in each row, column and 3×3 box must be different",
    "The number of empty cells",
    "The order in which cells are filled"
   ],
   "a": 1,
   "id": "Q099"
  },
  {
   "t": "mcq",
   "topic": "mea",
   "d": "easy",
   "q": "What is the central idea of means-end analysis?",
   "hint": "Ends = goals, means = operators.",
   "exp": "Means-end analysis repeatedly detects the most important difference between the current state and the goal state and picks an operator that reduces that difference.",
   "rw": false,
   "sp": false,
   "opts": [
    "Find the difference between the current state and the goal, then apply an operator that reduces it",
    "Accept worse states with decreasing probability",
    "Expand the shallowest node first",
    "Assign values to variables without violating constraints"
   ],
   "a": 0,
   "id": "Q100"
  },
  {
   "t": "fib",
   "topic": "mea",
   "d": "medium",
   "q": "Means-end analysis was first used by Newell and Simon in a program called the General Problem ______.",
   "hint": "Its abbreviation is GPS.",
   "exp": "The General Problem Solver (GPS), developed by Newell, Shaw and Simon, introduced means-end analysis.",
   "rw": false,
   "sp": false,
   "ans": [
    "solver"
   ],
   "id": "Q101"
  },
  {
   "t": "scenario",
   "topic": "mea",
   "d": "medium",
   "q": "You must get from your home in Bengaluru to a conference in Delhi. You reason: \"The biggest difference is the distance, so I will fly. To fly I must be at the airport, so first I need a cab. To book a cab I need my phone.\" Which problem-solving technique is this?",
   "hint": "Each step picks an operator for the biggest difference and then creates a sub-goal for its precondition.",
   "exp": "This is means-end analysis: reduce the largest difference with a suitable operator, and when the operator's preconditions are not met, set up a sub-goal to satisfy them.",
   "rw": true,
   "sp": false,
   "opts": [
    "Hill climbing",
    "Means-end analysis",
    "Breadth-first search",
    "Constraint propagation"
   ],
   "a": 1,
   "id": "Q102"
  },
  {
   "t": "tf",
   "topic": "mea",
   "d": "medium",
   "q": "Means-end analysis can mix forward and backward reasoning while solving a problem.",
   "hint": "It solves the major parts first and then connects the pieces.",
   "exp": "True. MEA lets the solver work on the major differences first and then return to the smaller problems that arise when joining the pieces, reasoning in both directions.",
   "rw": false,
   "sp": false,
   "a": true,
   "id": "Q103"
  },
  {
   "t": "mcq",
   "topic": "mea",
   "d": "hard",
   "q": "In means-end analysis, what happens when the operator chosen to reduce a difference cannot be applied to the current state?",
   "hint": "This is called operator subgoaling.",
   "exp": "MEA sets up a sub-problem of getting to a state in which the operator can be applied. Operator subgoaling like this is what makes MEA recursive.",
   "rw": false,
   "sp": false,
   "opts": [
    "The search stops and reports failure",
    "The goal state is changed",
    "A sub-goal is created to reach a state where the operator's preconditions hold",
    "A random operator is applied instead"
   ],
   "a": 2,
   "id": "Q104"
  },
  {
   "t": "mcq",
   "topic": "mea",
   "d": "medium",
   "q": "In means-end analysis, which data structure indexes the operators by the differences they can reduce?",
   "hint": "It pairs each kind of difference with the operators that help.",
   "exp": "A difference table lists, for each type of difference, the operators that can be used to reduce it.",
   "rw": false,
   "sp": false,
   "opts": [
    "Constraint graph",
    "Difference table",
    "OPEN list",
    "Percept sequence"
   ],
   "a": 1,
   "id": "Q105"
  }
 ]
};
