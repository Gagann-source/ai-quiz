/* Goal State AI Quiz - game logic */
// The question bank is loaded from questions.js as QUIZ_DATA
const DATA = QUIZ_DATA;
const QUESTIONS = DATA.questions, TOPICS = DATA.topics, AR_OPTS = DATA.arOpts;
const TOPIC = Object.fromEntries(TOPICS.map(t => [t.id, t]));
const TYPE = {mcq:"MCQ", tf:"True / False", ar:"Assertion–Reason", fib:"Fill in the blank", match:"Match the following", scenario:"Scenario", problem:"Problem solving"};
const POINTS = {easy:10, medium:15, hard:20};
const SECONDS = {easy:30, medium:45, hard:60};
const HINT_COST = 5, STREAK_BONUS = 5, STREAK_FROM = 3;
const LIFELINES = {hint:3, fifty:2, skip:1};

/* ---------- small helpers ---------- */
function el(tag, attrs, ...kids){
  const n = document.createElement(tag);
  for (const k in (attrs||{})){
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === "class") n.className = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else if (k === "disabled" || k === "hidden") n[k] = !!v;
    else n.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat(Infinity)) if (c != null && c !== false) n.append(c.nodeType ? c : document.createTextNode(String(c)));
  return n;
}
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const norm = s => String(s).toLowerCase().replace(/[^a-z0-9]/g, "");
const fmtTime = s => Math.floor(s / 60) + ":" + String(Math.round(s) % 60).padStart(2, "0");
const store = {
  get(k, d){ try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
function timeLimit(q){ return SECONDS[q.d] + (q.t === "match" || q.t === "problem" ? 15 : 0); }

/* ---------- pure quiz logic (also used by the tests) ---------- */
function buildQuiz(cfg){
  let pool = QUESTIONS.filter(q => (cfg.unit === 0 || TOPIC[q.topic].unit === cfg.unit) && (cfg.diff === "mixed" || q.d === cfg.diff));
  const n = Math.min(cfg.n, pool.length);
  // round-robin over topics so every run covers the syllabus as widely as possible
  const byTopic = {};
  for (const q of shuffle(pool)) (byTopic[q.topic] = byTopic[q.topic] || []).push(q);
  const picked = [];
  let topics = shuffle(Object.keys(byTopic));
  while (picked.length < n){
    for (const t of topics){ if (picked.length < n && byTopic[t].length) picked.push(byTopic[t].pop()); }
    topics = topics.filter(t => byTopic[t].length);
  }
  // make sure every question format appears when the run is long enough
  if (n >= 14){
    const rest = pool.filter(q => !picked.includes(q));
    for (const type of Object.keys(TYPE)){
      if (picked.some(q => q.t === type)) continue;
      const tc = {}, pc = {}; picked.forEach(q => { tc[q.t] = (tc[q.t] || 0) + 1; pc[q.topic] = (pc[q.topic] || 0) + 1; });
      // swap one in without dropping a topic or another format from the run
      search: for (const cand of shuffle(rest.filter(q => q.t === type))){
        for (let k = 0; k < picked.length; k++){
          const v = picked[k];
          if (tc[v.t] > 1 && (v.topic === cand.topic || pc[v.topic] > 1)){ picked[k] = cand; break search; }
        }
      }
    }
  }
  return shuffle(picked).map(makeItem);
}
function makeItem(q){
  const it = {q, status:null, chosen:null, hintUsed:false, hidden:[], pts:0, bonus:0, secs:0};
  if (q.opts) it.order = shuffle(q.opts.map((_, i) => i));
  if (q.t === "ar") it.order = [0, 1, 2, 3];
  if (q.t === "match"){ it.rights = shuffle(q.pairs.map(p => p[1])); it.chosen = q.pairs.map(() => ""); }
  if (q.t === "fib") it.chosen = "";
  return it;
}
function isCorrect(q, chosen){
  if (q.t === "fib") return q.ans.map(norm).includes(norm(chosen));
  if (q.t === "match") return q.pairs.every((p, i) => chosen[i] === p[1]);
  return chosen === q.a;
}
function hasAnswer(it){
  if (it.q.t === "fib") return norm(it.chosen).length > 0;
  if (it.q.t === "match") return it.chosen.every(v => v);
  return it.chosen !== null;
}
function answerText(q){
  if (q.t === "tf") return q.a ? "True" : "False";
  if (q.t === "ar") return AR_OPTS[q.a];
  if (q.t === "fib") return q.ans[0];
  if (q.t === "match") return q.pairs.map(p => p[0] + " → " + p[1]).join("; ");
  return q.opts[q.a];
}
function chosenText(it){
  const q = it.q, c = it.chosen;
  if (it.status === "timeout") return "No answer (time ran out)";
  if (q.t === "tf") return c ? "True" : "False";
  if (q.t === "ar") return AR_OPTS[c];
  if (q.t === "fib") return c || "(blank)";
  if (q.t === "match") return q.pairs.map((p, i) => p[0] + " → " + (c[i] || "—")).join("; ");
  return q.opts[c];
}
function grade(run, it, secs, timedOut){
  it.secs = secs;
  const ok = !timedOut && isCorrect(it.q, it.chosen);
  it.status = timedOut ? "timeout" : ok ? "correct" : "wrong";
  if (ok){
    run.streak++;
    run.bestStreak = Math.max(run.bestStreak, run.streak);
    it.pts = Math.max(0, POINTS[it.q.d] - (it.hintUsed ? HINT_COST : 0));
    it.bonus = run.streak >= STREAK_FROM ? STREAK_BONUS : 0;
    run.score += it.pts + it.bonus;
  } else run.streak = 0;
  return ok;
}
function summarise(run){
  const items = run.items, correct = items.filter(i => i.status === "correct").length;
  const max = items.reduce((s, i) => s + POINTS[i.q.d], 0);
  return {correct, total:items.length, max, acc:Math.round(100 * correct / items.length), secs:Math.round(items.reduce((s, i) => s + i.secs, 0))};
}
function verdict(acc){
  if (acc >= 90) return ["Goal state reached", "An optimal path. You are ready for the viva."];
  if (acc >= 75) return ["Admissible", "Close to the goal. Review the few you missed below."];
  if (acc >= 50) return ["Local maximum", "A decent peak, but there is higher ground. Restart and climb again."];
  return ["Still exploring", "Read the explanations below, then expand a few more nodes."];
}

/* ---------- state ---------- */
const S = {
  view:"home",
  cfg:Object.assign({name:"", n:10, diff:"mixed", unit:0, timer:true}, store.get("gs_cfg", {})),
  run:null, last:null,
  bank:{unit:0, topic:"", type:"", answers:false},
  boardN:0, confirmClear:false
};
let tick = null, qStart = 0, db = null, shared = null;
const app = document.getElementById("app");

/* ---------- leaderboard storage ---------- */
function localScores(){ const v = store.get("gs_scores", []); return Array.isArray(v) ? v : []; }
function cleanEntry(e){
  return {id:String(e.id || "").slice(0, 40), name:String(e.name || "Player").slice(0, 24), score:+e.score || 0, max:+e.max || 0,
    acc:+e.acc || 0, n:+e.n || 0, diff:String(e.diff || "mixed").slice(0, 8), unit:+e.unit || 0, secs:+e.secs || 0, timer:e.timer !== false, at:+e.at || 0};
}
function allScores(){
  const m = new Map();
  for (const e of localScores()) m.set(e.id, cleanEntry(e));
  for (const e of (shared || [])) m.set(e.id, cleanEntry(e));
  return [...m.values()].sort((a, b) => b.score - a.score || b.acc - a.acc || a.secs - b.secs);
}
function postScore(entry){
  store.set("gs_scores", localScores().concat(entry).slice(-200));
  if (db) db.collection("scores").doc(entry.id).set(entry).catch(() => {});
}
(async () => {
  try { db = await (window.claude && window.claude.use ? window.claude.use("db") : null); } catch { db = null; }
  if (!db) return;
  try {
    db.collection("scores").orderBy("score", "desc").limit(200).onSnapshot(
      snap => { shared = snap.docs.map(d => Object.assign({}, d.data(), {id:d.id})); if (S.view === "board") render(); },
      () => { db = null; shared = null; if (S.view === "board") render(); });
  } catch { db = null; }
})();

/* ---------- navigation ---------- */
const NAV = [["home", "Play"], ["board", "Leaderboard"], ["bank", "Question bank"], ["about", "How it works"]];
function go(view){ stopTimer(); S.view = view; S.confirmClear = false; render(); window.scrollTo(0, 0); }
document.getElementById("home-link").addEventListener("click", () => go("home"));
function renderNav(){
  const nav = document.getElementById("nav"); nav.replaceChildren();
  const cur = (S.view === "quiz" || S.view === "result") ? "home" : S.view;
  for (const [v, label] of NAV) nav.append(el("button", {"aria-current": cur === v ? "page" : null, onclick: () => go(v)}, label));
}
function render(){
  renderNav();
  const view = {home:viewHome, quiz:viewQuiz, result:viewResult, board:viewBoard, bank:viewBank, about:viewAbout}[S.view]();
  app.replaceChildren(view);
}
function seg(label, value, options, onpick){
  return el("div", {class:"field"}, el("span", {class:"lab"}, label),
    el("div", {class:"seg", role:"group", "aria-label":label},
      options.map(([v, text]) => el("button", {"aria-pressed": String(v === value), onclick: () => onpick(v)}, text))));
}

/* ---------- home ---------- */
function poolSize(){ return QUESTIONS.filter(q => (S.cfg.unit === 0 || TOPIC[q.topic].unit === S.cfg.unit) && (S.cfg.diff === "mixed" || q.d === S.cfg.diff)).length; }
function setCfg(k, v){ S.cfg[k] = v; store.set("gs_cfg", S.cfg); render(); }
function viewHome(){
  const size = poolSize(), n = Math.min(S.cfg.n, size);
  const name = el("input", {type:"text", id:"player-name", maxlength:"24", placeholder:"e.g. Gagan", value:S.cfg.name, autocomplete:"off",
    oninput: e => { S.cfg.name = e.target.value; store.set("gs_cfg", S.cfg); }});
  return el("div", {class:"stack", style:"gap:24px"},
    el("section", {class:"hero stack", style:"gap:10px"},
      el("span", {class:"eyebrow"}, "DSC401-6 Artificial Intelligence · Units I & II"),
      el("h1", {}, "Search your way to the goal state."),
      el("p", {}, "A timed quiz on agents, environments, state-space search, heuristics, CSPs and means-end analysis. Every question you answer adds a node to your path.")),
    el("div", {class:"home-grid"},
      el("section", {class:"panel stack"},
        el("h2", {style:"font-size:22px"}, "Set up your run"),
        el("div", {class:"field"}, el("label", {for:"player-name"}, "Your name (shown on the leaderboard)"), name),
        seg("Number of questions", S.cfg.n, [[10, "10 · Quick"], [20, "20 · Standard"], [50, "50 · Full"]], v => setCfg("n", v)),
        seg("Difficulty", S.cfg.diff, [["mixed", "Mixed"], ["easy", "Easy"], ["medium", "Medium"], ["hard", "Hard"]], v => setCfg("diff", v)),
        seg("Syllabus", S.cfg.unit, [[0, "Units I & II"], [1, "Unit I"], [2, "Unit II"]], v => setCfg("unit", v)),
        seg("Timer", S.cfg.timer, [[true, "On"], [false, "Off (practice)"]], v => setCfg("timer", v)),
        el("p", {class:"muted", style:"font-size:14px"}, size < S.cfg.n
          ? "Only " + size + " questions match these filters, so this run will have " + n + "."
          : n + " questions drawn at random from " + size + " that match."),
        el("div", {}, el("button", {class:"btn", id:"start-btn", onclick:startQuiz}, "Start quiz"))),
      el("aside", {class:"stack"},
        el("div", {class:"panel stack"},
          el("div", {class:"facts"},
            el("div", {class:"fact"}, el("b", {}, QUESTIONS.length), el("span", {}, "questions")),
            el("div", {class:"fact"}, el("b", {}, TOPICS.length), el("span", {}, "topics")),
            el("div", {class:"fact"}, el("b", {}, Object.keys(TYPE).length), el("span", {}, "formats"))),
          el("ul", {class:"rules"},
            el("li", {}, "Easy 10, medium 15, hard 20 points."),
            el("li", {}, "Three correct in a row starts a streak: +5 for each correct answer while it lasts."),
            el("li", {}, "Lifelines per run: 3 hints (−5 points each), two 50:50s, one skip."),
            el("li", {}, "You see the right answer and the reason after every question."))))));
}

/* ---------- quiz ---------- */
function startQuiz(){
  const items = buildQuiz(S.cfg);
  S.run = {items, i:0, score:0, streak:0, bestStreak:0, life:Object.assign({}, LIFELINES), cfg:Object.assign({}, S.cfg),
    used:new Set(items.map(it => it.q.id))};
  S.view = "quiz"; render(); startTimer(); window.scrollTo(0, 0);
}
function cur(){ return S.run.items[S.run.i]; }
function stopTimer(){ if (tick){ clearInterval(tick); tick = null; } }
function startTimer(){
  stopTimer(); qStart = Date.now();
  tick = setInterval(() => {
    const it = cur(); if (!it || it.status){ stopTimer(); return; }
    if (!S.run.cfg.timer) return;
    const limit = timeLimit(it.q), left = limit - (Date.now() - qStart) / 1000;
    const bar = document.getElementById("timer-bar"), txt = document.getElementById("timer-text");
    if (bar){ bar.style.width = Math.max(0, 100 * left / limit) + "%"; bar.parentNode.classList.toggle("low", left <= 10); }
    if (txt) txt.textContent = Math.max(0, Math.ceil(left)) + "s";
    if (left <= 0) submit(true);
  }, 200);
}
function submit(timedOut){
  const it = cur(); if (it.status) return;
  if (!timedOut && !hasAnswer(it)) return;
  stopTimer();
  grade(S.run, it, Math.min((Date.now() - qStart) / 1000, timeLimit(it.q)), timedOut);
  render();
  const nb = document.getElementById("next-btn"); if (nb) nb.focus();
}
function next(){
  if (S.run.i + 1 >= S.run.items.length) return finish();
  S.run.i++; render(); startTimer(); window.scrollTo(0, 0);
}
function finish(){
  stopTimer();
  const run = S.run, sum = summarise(run);
  const entry = {id:Date.now().toString(36) + Math.random().toString(36).slice(2, 8), name:(run.cfg.name || "").trim().slice(0, 24) || "Player",
    score:run.score, max:sum.max, acc:sum.acc, n:sum.total, diff:run.cfg.diff, unit:run.cfg.unit, secs:sum.secs, timer:run.cfg.timer, at:Date.now()};
  postScore(entry);
  S.last = {run, sum, entry}; S.view = "result"; render(); window.scrollTo(0, 0);
}
function useHint(){ const it = cur(); if (it.status || it.hintUsed || !S.run.life.hint) return; S.run.life.hint--; it.hintUsed = true; render(); }
function useFifty(){
  const it = cur(), q = it.q;
  if (it.status || it.hidden.length || !S.run.life.fifty || !q.opts && q.t !== "ar") return;
  const wrong = shuffle([0, 1, 2, 3].filter(i => i !== q.a)).slice(0, 2);
  it.hidden = wrong; if (wrong.includes(it.chosen)) it.chosen = null;
  S.run.life.fifty--; render();
}
function useSkip(){
  const it = cur(); if (it.status || !S.run.life.skip) return;
  const c = S.run.cfg;
  const pool = QUESTIONS.filter(q => !S.run.used.has(q.id) && (c.unit === 0 || TOPIC[q.topic].unit === c.unit) && (c.diff === "mixed" || q.d === c.diff));
  if (!pool.length) return;
  const q = shuffle(pool)[0]; S.run.used.add(q.id); S.run.life.skip--;
  S.run.items[S.run.i] = makeItem(q); render(); startTimer();
}
function tagsFor(q){
  return el("div", {class:"tags"},
    el("span", {class:"tag type"}, TYPE[q.t]),
    el("span", {class:"tag"}, "Unit " + ["", "I", "II"][TOPIC[q.topic].unit] + " · " + TOPIC[q.topic].name),
    el("span", {class:"tag"}, q.d + " · " + POINTS[q.d] + " pts"),
    q.rw ? el("span", {class:"tag"}, "real-world") : null,
    q.sp ? el("span", {class:"tag"}, "search problem") : null);
}
function answerArea(it){
  const q = it.q, done = !!it.status;
  if (q.t === "fib"){
    const inp = el("input", {type:"text", id:"fib-input", placeholder:"Type the missing word", autocomplete:"off", value:it.chosen, disabled:done,
      oninput: e => { it.chosen = e.target.value; document.getElementById("submit-btn").disabled = !hasAnswer(it); }});
    return el("div", {class:"field"}, el("label", {for:"fib-input"}, "Your answer"), inp);
  }
  if (q.t === "match"){
    return el("div", {}, q.pairs.map((p, i) => {
      const sel = el("select", {id:"match-" + i, "aria-label":"Match for " + p[0], disabled:done,
        onchange: e => { it.chosen[i] = e.target.value; render(); const s = document.getElementById("match-" + i); if (s) s.focus(); }},
        el("option", {value:""}, "Choose…"), it.rights.map(r => el("option", {value:r, selected:it.chosen[i] === r}, r)));
      const mark = done ? (it.chosen[i] === p[1] ? el("span", {class:"mark-ok"}, " ✓") : el("span", {class:"mark-no"}, " ✗")) : null;
      return el("div", {class:"mrow"}, el("div", {}, el("b", {}, p[0]), mark),
        el("div", {class:"stack", style:"gap:4px;min-width:0"}, sel, it.chosen[i] ? el("div", {class:"muted", style:"font-size:14px"}, it.chosen[i]) : null));
    }));
  }
  const list = q.t === "tf" ? [[true, "True"], [false, "False"]] : (q.t === "ar" ? AR_OPTS : q.opts) && it.order.map(i => [i, (q.t === "ar" ? AR_OPTS : q.opts)[i]]);
  return el("div", {class:"opts", role:"group", "aria-label":"Answer options"}, list.map(([val, text], pos) => {
    const gone = it.hidden.includes(val);
    let cls = "opt";
    if (done){ if (val === q.a) cls += " right"; else if (val === it.chosen) cls += " wrong"; }
    else if (val === it.chosen) cls += " sel";
    if (gone) cls += " gone";
    return el("button", {class:cls, disabled:done || gone, "aria-pressed":String(val === it.chosen), "data-pos":pos,
      onclick: () => { it.chosen = val; render(); const b = document.getElementById("submit-btn"); if (b) b.focus(); }},
      el("span", {class:"k"}, "ABCD"[pos]), el("span", {}, text));
  }));
}
function viewQuiz(){
  const run = S.run, it = cur(), q = it.q, done = !!it.status, last = run.i + 1 >= run.items.length;
  const path = el("div", {class:"path", role:"img", "aria-label":"Question " + (run.i + 1) + " of " + run.items.length},
    run.items.map((x, i) => [i ? el("span", {class:"edge"}) : null,
      el("span", {class:"node" + (x.status === "correct" ? " ok" : x.status ? " no" : i === run.i ? " cur" : "")})]));
  const optionType = q.t !== "fib" && q.t !== "match" && q.t !== "tf";
  const kids = [
    el("div", {class:"hud"},
      el("div", {}, el("span", {}, "Question"), el("b", {}, (run.i + 1) + " / " + run.items.length)),
      el("div", {}, el("span", {}, "Score"), el("b", {id:"hud-score"}, run.score)),
      el("div", {}, el("span", {}, "Streak"), el("b", {}, run.streak + (run.streak >= STREAK_FROM ? " (+5)" : ""))),
      el("div", {}, el("span", {}, "Time left"), el("b", {id:"timer-text"}, !run.cfg.timer ? "off" : done ? "—" : timeLimit(q) + "s"))),
    path,
    run.cfg.timer ? el("div", {class:"timer"}, el("i", {id:"timer-bar", style: done ? "width:0" : null})) : null,
    el("section", {class:"panel stack"},
      tagsFor(q),
      el("h2", {class:"qtext", id:"q-text", style:"font-family:var(--body)"}, q.q),
      answerArea(it),
      it.hintUsed ? el("div", {class:"hint"}, el("b", {}, "Hint: "), q.hint) : null,
      done ? feedback(it) : null,
      done
        ? el("div", {class:"row"}, el("button", {class:"btn", id:"next-btn", onclick:next}, last ? "See results" : "Next question"))
        : el("div", {class:"row", style:"justify-content:space-between"},
            el("button", {class:"btn", id:"submit-btn", disabled:!hasAnswer(it), onclick: () => submit(false)}, "Submit answer"),
            el("div", {class:"life"},
              el("button", {id:"life-hint", disabled:!run.life.hint || it.hintUsed, onclick:useHint}, "Hint −5 (" + run.life.hint + ")"),
              el("button", {id:"life-fifty", disabled:!run.life.fifty || !optionType || it.hidden.length > 0, onclick:useFifty}, "50:50 (" + run.life.fifty + ")"),
              el("button", {id:"life-skip", disabled:!run.life.skip, onclick:useSkip}, "Skip (" + run.life.skip + ")")))),
    el("div", {}, el("button", {class:"btn ghost small", onclick: () => go("home")}, "Quit run"))
  ];
  return el("div", {class:"stack"}, kids);
}
function feedback(it){
  const ok = it.status === "correct";
  const head = ok ? "Correct  +" + it.pts + (it.bonus ? "  (+" + it.bonus + " streak bonus)" : "") : it.status === "timeout" ? "Time's up" : "Not quite";
  return el("div", {class:"fb " + (ok ? "ok" : "no"), role:"status"},
    el("h3", {}, head),
    ok ? null : el("p", {}, el("b", {}, "Correct answer: "), answerText(it.q)),
    el("p", {}, it.q.exp));
}
document.addEventListener("keydown", e => {
  if (S.view !== "quiz" || e.ctrlKey || e.metaKey || e.altKey) return;
  const it = cur(), tag = (e.target.tagName || "").toLowerCase();
  if (tag === "input" || tag === "select"){ if (e.key === "Enter" && !it.status){ e.preventDefault(); submit(false); } return; }
  if (it.status) return;   // Enter on the focused Next button already advances
  const pos = "1234".indexOf(e.key) >= 0 ? "1234".indexOf(e.key) : "abcd".indexOf(e.key.toLowerCase());
  if (pos >= 0 && e.key.length === 1){ const b = app.querySelector('.opt[data-pos="' + pos + '"]'); if (b && !b.disabled) b.click(); }
});

/* ---------- result ---------- */
function breakdown(items, keyFn, labelFn){
  const m = new Map();
  for (const it of items){ const k = keyFn(it.q); const v = m.get(k) || [0, 0]; v[1]++; if (it.status === "correct") v[0]++; m.set(k, v); }
  return el("div", {class:"bars"}, [...m.entries()].map(([k, [c, t]]) =>
    el("div", {class:"bar"}, el("span", {style:"min-width:0;overflow-wrap:anywhere"}, labelFn(k)),
      el("span", {class:"track"}, el("i", {style:"width:" + (100 * c / t) + "%"})), el("span", {class:"mono"}, c + "/" + t))));
}
function viewResult(){
  const {run, sum, entry} = S.last, [title, line] = verdict(sum.acc);
  const rank = allScores().filter(e => e.n === entry.n).findIndex(e => e.id === entry.id) + 1;
  const topicOrder = TOPICS.map(t => t.id);
  const sorted = run.items.slice().sort((a, b) => topicOrder.indexOf(a.q.topic) - topicOrder.indexOf(b.q.topic));
  return el("div", {class:"stack", style:"gap:22px"},
    el("section", {class:"panel stack"},
      el("span", {class:"eyebrow"}, "Result for " + entry.name),
      el("h1", {style:"font-size:clamp(28px,5vw,40px);font-weight:800"}, title),
      el("div", {class:"score-line"},
        el("span", {class:"big", id:"final-score"}, run.score),
        el("span", {class:"mono muted"}, "points (" + sum.max + " available before streak bonuses)"),
        el("span", {class:"mono"}, sum.correct + "/" + sum.total + " correct · " + sum.acc + "%"),
        el("span", {class:"mono"}, "best streak " + run.bestStreak),
        el("span", {class:"mono"}, "time " + fmtTime(sum.secs))),
      el("p", {}, line + (rank ? " You are #" + rank + " on the " + entry.n + "-question board." : "")),
      el("div", {class:"row"},
        el("button", {class:"btn", id:"again-btn", onclick:startQuiz}, "Play again"),
        el("button", {class:"btn ghost", onclick: () => { S.boardN = entry.n; go("board"); }}, "View leaderboard"))),
    el("section", {class:"panel stack"}, el("h2", {style:"font-size:20px"}, "Score by topic"), breakdown(sorted, q => q.topic, k => TOPIC[k].name)),
    el("section", {class:"panel stack"}, el("h2", {style:"font-size:20px"}, "Score by question format"), breakdown(run.items, q => q.t, k => TYPE[k])),
    el("section", {class:"panel"}, el("h2", {style:"font-size:20px;margin-bottom:10px"}, "Review your answers"),
      run.items.map((it, i) => el("div", {class:"rev"},
        el("div", {class:"row"}, el("span", {class:"mono muted"}, "Q" + (i + 1)),
          el("span", {class: it.status === "correct" ? "st-ok" : "st-no"}, it.status === "correct" ? "Correct +" + (it.pts + it.bonus) : it.status === "timeout" ? "Timed out" : "Wrong"),
          el("span", {class:"tag"}, TYPE[it.q.t]), el("span", {class:"tag"}, TOPIC[it.q.topic].name)),
        el("div", {class:"qtext"}, it.q.q),
        it.status === "correct" ? null : el("div", {class:"muted"}, "Your answer: " + chosenText(it)),
        el("div", {class:"ans"}, el("b", {}, "Answer: "), answerText(it.q), el("div", {style:"margin-top:4px"}, it.q.exp))))));
}

/* ---------- leaderboard ---------- */
function viewBoard(){
  const all = allScores(), rows = all.filter(e => !S.boardN || e.n === S.boardN).slice(0, 50), mine = S.last && S.last.entry.id;
  const unitName = u => u === 1 ? "Unit I" : u === 2 ? "Unit II" : "Units I & II";
  return el("div", {class:"stack"},
    el("div", {class:"stack", style:"gap:6px"},
      el("h1", {style:"font-size:clamp(28px,5vw,40px);font-weight:800"}, "Leaderboard"),
      el("p", {class:"muted"}, shared ? "Scores are shared with everyone who can play on this page." : "Scores are saved in this browser.")),
    seg("Show", S.boardN, [[0, "All runs"], [10, "10 questions"], [20, "20 questions"], [50, "50 questions"]], v => { S.boardN = v; render(); }),
    rows.length ? el("div", {class:"panel scroll"}, el("table", {},
      el("thead", {}, el("tr", {}, el("th", {}, "#"), el("th", {}, "Player"), el("th", {class:"num"}, "Score"), el("th", {class:"num"}, "Accuracy"),
        el("th", {}, "Run"), el("th", {class:"num"}, "Time"), el("th", {}, "Date"))),
      el("tbody", {}, rows.map((e, i) => el("tr", {class: e.id === mine ? "me" : null},
        el("td", {class:"num"}, i + 1), el("td", {}, e.name), el("td", {class:"num"}, e.score), el("td", {class:"num"}, e.acc + "%"),
        el("td", {}, e.n + " Q · " + e.diff + " · " + unitName(e.unit) + (e.timer ? "" : " · untimed")),
        el("td", {class:"num"}, fmtTime(e.secs)), el("td", {}, e.at ? new Date(e.at).toLocaleDateString(undefined, {day:"numeric", month:"short"}) : ""))))))
      : el("div", {class:"empty"}, el("b", {}, "No scores here yet. "), "Finish a quiz and your name, score, accuracy and time will appear in this table.",
          el("div", {style:"margin-top:12px"}, el("button", {class:"btn small", onclick: () => go("home")}, "Play a run"))),
    localScores().length ? el("div", {class:"row"},
      S.confirmClear
        ? [el("span", {}, "Remove the scores saved in this browser?"),
           el("button", {class:"btn small", id:"clear-yes", onclick: () => { store.set("gs_scores", []); S.confirmClear = false; render(); }}, "Yes, clear them"),
           el("button", {class:"btn ghost small", onclick: () => { S.confirmClear = false; render(); }}, "Keep them")]
        : el("button", {class:"btn ghost small", id:"clear-btn", onclick: () => { S.confirmClear = true; render(); }}, "Clear this browser's scores")) : null);
}

/* ---------- question bank ---------- */
function viewBank(){
  const b = S.bank;
  const list = QUESTIONS.filter(q => (!b.unit || TOPIC[q.topic].unit === b.unit) && (!b.topic || q.topic === b.topic) && (!b.type || q.t === b.type));
  const pick = (id, label, value, options, set) => el("div", {class:"field"}, el("label", {for:id}, label),
    el("select", {id, onchange: e => { set(e.target.value); render(); }}, options.map(([v, t]) => el("option", {value:v, selected:String(v) === String(value)}, t))));
  return el("div", {class:"stack"},
    el("div", {class:"stack", style:"gap:6px"},
      el("h1", {style:"font-size:clamp(28px,5vw,40px);font-weight:800"}, "Question bank"),
      el("p", {class:"muted"}, "All " + QUESTIONS.length + " questions the game draws from, with answers and explanations.")),
    el("div", {class:"row", style:"align-items:flex-end;gap:14px"},
      pick("bank-unit", "Unit", b.unit, [[0, "Both units"], [1, "Unit I"], [2, "Unit II"]], v => { b.unit = +v; b.topic = ""; }),
      pick("bank-topic", "Topic", b.topic, [["", "All topics"]].concat(TOPICS.filter(t => !b.unit || t.unit === b.unit).map(t => [t.id, t.name])), v => b.topic = v),
      pick("bank-type", "Format", b.type, [["", "All formats"]].concat(Object.entries(TYPE)), v => b.type = v),
      el("button", {class:"btn ghost small", id:"bank-answers", "aria-pressed":String(b.answers), onclick: () => { b.answers = !b.answers; render(); }}, b.answers ? "Hide answers" : "Show answers")),
    el("p", {class:"mono muted", style:"font-size:13px"}, list.length + " question" + (list.length === 1 ? "" : "s") + " shown"),
    el("section", {class:"panel"}, list.length ? list.map(q => el("div", {class:"bank-item"},
      el("div", {class:"row"}, el("span", {class:"mono"}, q.id), tagsFor(q)),
      el("div", {class:"qtext", style:"font-size:17px"}, q.q),
      q.opts ? el("ol", {type:"A"}, q.opts.map(o => el("li", {}, o))) : null,
      q.t === "ar" ? el("ol", {type:"A"}, AR_OPTS.map(o => el("li", {}, o))) : null,
      q.t === "match" ? el("div", {class:"muted", style:"font-size:15px"}, "Items: " + q.pairs.map(p => p[0]).join(" · ")) : null,
      b.answers ? el("div", {class:"ans"}, el("b", {}, "Answer: "),
        (q.opts || q.t === "ar" ? "ABCD"[q.a] + ". " : "") + answerText(q), el("div", {style:"margin-top:4px"}, q.exp)) : null))
      : el("div", {class:"muted"}, "No questions match these filters.")));
}

/* ---------- how it works ---------- */
function viewAbout(){
  const count = f => QUESTIONS.filter(f).length;
  const li = (...t) => el("li", {}, ...t);
  return el("div", {class:"stack"},
    el("h1", {style:"font-size:clamp(28px,5vw,40px);font-weight:800"}, "How it works"),
    el("section", {class:"panel stack"},
      el("h2", {style:"font-size:20px"}, "Game design"),
      el("ul", {class:"rules"},
        li(el("b", {}, "Random questions. "), "Each run draws questions at random, taking topics in turn so the run covers as much of the syllabus as its length allows. Option order is shuffled every time."),
        li(el("b", {}, "Difficulty levels. "), "Easy, medium and hard questions are worth 10, 15 and 20 points and allow 30, 45 and 60 seconds. Matching and problem-solving questions get 15 seconds more."),
        li(el("b", {}, "Timer. "), "The bar above the question counts down. If it reaches zero the question is marked as timed out."),
        li(el("b", {}, "Immediate feedback. "), "After each answer you see whether it was right, the correct answer and a short explanation."),
        li(el("b", {}, "Lifelines. "), "Hint (3 per run, costs 5 points on that question), 50:50 (2 per run, removes two wrong options), Skip (1 per run, swaps the question for another)."),
        li(el("b", {}, "Streak bonus. "), "From the third correct answer in a row, each correct answer earns 5 extra points until you miss one."),
        li(el("b", {}, "Progress. "), "The row of nodes shows your path: green for correct, red for wrong or timed out, yellow for the current question."),
        li(el("b", {}, "Result and leaderboard. "), "The result page shows score, accuracy, time, a topic-wise breakdown and a full review. Every finished run is added to the leaderboard."))),
    el("section", {class:"panel stack"},
      el("h2", {style:"font-size:20px"}, "What the question bank covers"),
      el("p", {}, QUESTIONS.length + " questions: " + count(q => q.rw) + " based on real-world AI applications or scenarios and " + count(q => q.sp) + " search or state-space problems."),
      el("div", {class:"scroll"}, el("table", {},
        el("thead", {}, el("tr", {}, el("th", {}, "Format"), el("th", {class:"num"}, "Questions"))),
        el("tbody", {}, Object.entries(TYPE).map(([k, v]) => el("tr", {}, el("td", {}, v), el("td", {class:"num"}, count(q => q.t === k))))))),
      el("div", {class:"scroll"}, el("table", {},
        el("thead", {}, el("tr", {}, el("th", {}, "Unit"), el("th", {}, "Topic"), el("th", {class:"num"}, "Questions"))),
        el("tbody", {}, TOPICS.map(t => el("tr", {}, el("td", {}, t.unit === 1 ? "I" : "II"), el("td", {style:"white-space:normal"}, t.name), el("td", {class:"num"}, count(q => q.topic === t.id)))))))));
}

window.__quiz = {S, buildQuiz, isCorrect, grade, summarise, makeItem};
const start = () => { if (location.hash === "#leaderboard") S.view = "board"; else if (location.hash === "#bank") S.view = "bank"; render(); };
start();
